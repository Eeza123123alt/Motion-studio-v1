# Motion Studio

A free, local-first browser video-editor prototype. It is an original project and does not include CapCut code, branding, assets, or proprietary templates.

## Included in this first build

- Import one local video and preview it on a canvas.
- Add multiple text layers and set their start/end times.
- Font family, size, bold, italic, alignment, colour, letter spacing.
- Text outline, shadow, optional background, X/Y position, scale and rotation.
- Text motion presets: fade, pop, slide, zoom, wave, bounce, shake and typewriter; plus basic exit animations.
- Transform keyframes for X, Y, scale, rotation and opacity, with easing and interpolation.
- Video adjustments: brightness, contrast, saturation, blur, sepia and grayscale.
- Basic video masks: rectangle, rounded rectangle and ellipse, with size and position controls.
- Add a music track and adjust video/music volume.
- Save project settings as JSON (media files must be re-imported separately).
- Browser-based export through Canvas capture + MediaRecorder where supported.
- Load local TTF/OTF/WOFF fonts for the current session.

## Run it

The simplest route is to open `index.html` in a modern desktop browser. For best compatibility with local media, audio, and export, use a local static web server:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000`.

To use it on an iPhone, put this folder on a static host (for example, GitHub Pages) and open the page in Safari. The page itself uses no paid APIs, no account, and no external libraries. Browser codec support varies: export uses MP4 when the browser supports it, otherwise WebM. Mobile Safari may restrict recording/export depending on its version and device resources; desktop Chrome or Safari is the most reliable first test.

## Important limitations

This is a functional starter editor, not a full replacement for CapCut. It currently supports one main video clip plus text overlays and one music bed. It does not yet include multi-clip trimming/splitting, transitions between multiple video clips, stickers, speed ramping, chroma key, motion tracking, advanced feathered/vector masks, auto captions, proxy media, or project-embedded media. Text animation and export are rendered in real time, so long/high-resolution exports may be slow.

## Modify with AI

The main files are:

- `index.html` — controls and editor layout.
- `styles.css` — appearance and responsive design.
- `app.js` — editing state, canvas renderer, keyframes, masks, audio and export.

You can ask an AI coding assistant to edit these files. Keep a backup before large changes and test with short clips first.

## Privacy

Media is loaded through local browser file inputs and processed in the browser. No upload endpoint or analytics is included in this code.
